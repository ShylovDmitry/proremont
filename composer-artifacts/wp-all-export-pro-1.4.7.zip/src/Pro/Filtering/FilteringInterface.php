<?php

namespace Wpae\Pro\Filtering;


/**
 * Interface FilteringInterface
 * @package Wpae\Pro\Filtering
 */
interface FilteringInterface
{

}