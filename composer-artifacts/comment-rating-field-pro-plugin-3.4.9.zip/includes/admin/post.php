<?php
/**
* Post class
* 
* @package Comment_Rating_Field_Pro
* @author Tim Carr
* @version 1.0
*/
class Comment_Rating_Field_Pro_Post {

    /**
     * Holds the class object.
     *
     * @since   3.2.6
     *
     * @var     object
     */
    public static $instance;

     /**
     * Holds the base class object.
     *
     * @since   3.4.7
     *
     * @var     object
     */
    private $base;

	/**
	 * Constructor
	 *
     * @since   3.2.0
	 */
	public function __construct() {

		// Actions and Filters
		add_action( 'admin_menu', array( $this, 'register_meta_box' ) );
        add_action( 'save_post', array( $this, 'save_post' ) );

        // Get all Post Types with Comments Enabled
        $post_types = Comment_Rating_Field_Pro_Common::get_instance()->get_post_types();
        foreach ( (array) $post_types as $post_type ) {
            add_filter( 'manage_edit-' . $post_type->name . '_columns', array( $this, 'admin_columns' ) );
            add_action( 'manage_' . $post_type->name . '_posts_custom_column', array( $this, 'admin_columns_output'), 10, 2 );
        }
        
	}

    /**
     * Adds columns to all Post Types that have comments enabled
     * 
     * @since   3.2.7
     *
     * @param   array   $columns    Columns
     * @return  array               New Columns
     */
    public function admin_columns( $columns ) {

        $columns['crfp_average_rating'] = __( 'Average Rating', 'comment-rating-field-pro-plugin' );
        $columns['crfp_total_ratings']  = __( 'Total Ratings', 'comment-rating-field-pro-plugin' );

        return $columns;

    }

    /**
     * Manages the data to be displayed within a column within 
     * the WordPress Administration List Table
     * 
     * @since   3.2.7
     *
     * @param   string  $column_name    Column Name
     * @param   int     $post_id        Post ID
     */
    public function admin_columns_output( $column_name, $post_id ) {

        switch ( $column_name ) {

            /**
            * Average Rating
            */
            case 'crfp_average_rating':
                echo get_post_meta( $post_id, 'crfp-average-rating', true );
                break;

            /**
            * Total Ratings
            */
            case 'crfp_total_ratings':
                echo get_post_meta( $post_id, 'crfp-total-ratings', true );
                break;

        }

    }

	/**
     * Registers a meta box on Posts, Pages and CPTs, for displaying Post-specific options.
     *
     * @since   3.2.0
     */
    public function register_meta_box() {

        // Get base instance
        $this->base = Comment_Rating_Field_Pro::get_instance();

    	// Get post types
    	$post_types = Comment_Rating_Field_Pro_Common::get_instance()->get_post_types();
    	if ( ! is_array( $post_types ) ) {
    		return;
    	}

    	foreach ( $post_types as $post_type => $data ) {
    		// Register meta box on this Post Type
        	add_meta_box( $this->base->plugin->name, $this->base->plugin->displayName, array( $this, 'display_meta_box' ), $post_type, 'side', 'low' );
    	}

    }

    /**
     * Outputs the meta box for Posts
     *
     * @since 3.2.0
     */
    public function display_meta_box( $post ) {

    	// Check if the Post has any comments
        $comments = get_comments( array(
            'post_id'   => $post->ID,
            'meta_query'=> array(
                array(
                    'key'       => 'crfp',
                    'compare'   => 'EXISTS',
                ),
            ),
        ) );

        // Check if Ratings are disabled
        $disabled = get_post_meta( $post->ID, 'crfp-disabled', true );

        // Render view
        include_once( $this->base->plugin->folder . '/views/admin/post.php' );

	}

    /**
     * Save Post metadata
     *
     * @since   3.2.7
     *
     * @param    int     $post_id    Post ID
     * @return
     */
    public function save_post( $post_id ) {

        // Get base instance
        $this->base = Comment_Rating_Field_Pro::get_instance();

        // Run security checks
        // Missing nonce 
        if ( ! isset( $_POST[ $this->base->plugin->name . '_nonce' ] ) ) { 
            return;
        }

        // Invalid nonce
        if ( ! wp_verify_nonce( $_POST[ $this->base->plugin->name . '_nonce' ], 'save' ) ) {
            return;
        }

        // Save disabled option
        $disabled = ( isset( $_POST[ $this->base->plugin->name ]['disabled'] ) ? true : false );
        update_post_meta( $post_id, 'crfp-disabled', $disabled );

    }

    /**
     * Returns the singleton instance of the class.
     *
     * @since 3.2.6
     *
     * @return object Class.
     */
    public static function get_instance() {

        if ( ! isset( self::$instance ) && ! ( self::$instance instanceof self ) ) {
            self::$instance = new self;
        }

        return self::$instance;

    }

}