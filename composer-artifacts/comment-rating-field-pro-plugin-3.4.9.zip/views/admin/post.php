<?php
// Reset Ratings
if ( count( $comments ) > 0 ) {
    ?>
    <div class="option">
        <div class="full">
            <a href="#" class="button button-red crfp-delete-ratings"><?php _e( 'Delete All Ratings', 'comment-rating-field-pro-plugin' ); ?></a>
        
            <p class="description">
                <?php
                if ( count( $comments ) > 0 ) {
                    _e( 'Use this option to delete all ratings on comments made to this Post, as well as deleting the Post rating.', 'comment-rating-field-pro-plugin' );
                } else {
                    _e( 'No comments with ratings have been made against this Post yet.', 'comment-rating-field-pro-plugin' );
                }
                ?>
            </p>
        </div>
    </div>
    <?php
}

// Disable Ratings
?>
<div class="option">
    <div class="left">
        <strong><?php _e( 'Disable?', 'comment-rating-field-pro-plugin' ); ?></strong>
    </div>
    <div class="right">
        <input type="checkbox" name="<?php echo $this->base->plugin->name; ?>[disabled]" value="1"<?php checked( $disabled, 1 ); ?> />
    </div>
    <p class="description">
        <?php _e( 'If checked, disables rating input and output on the comment form for this Post.  Note: Any shortcodes or template tags manually inserted will continue to output ratings.', 'comment-rating-field-pro-plugin' ); ?>
    </p>
</div>

<?php 
// Nonce field
wp_nonce_field( 'save', $this->base->plugin->name . '_nonce' );