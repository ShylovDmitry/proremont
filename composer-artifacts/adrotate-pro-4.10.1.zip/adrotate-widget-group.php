<?php
/* ------------------------------------------------------------------------------------
*  COPYRIGHT AND TRADEMARK NOTICE
*  Copyright 2008-2017 Arnan de Gans. All Rights Reserved.
*  ADROTATE is a registered trademark of Arnan de Gans.

*  COPYRIGHT NOTICES AND ALL THE COMMENTS SHOULD REMAIN INTACT.
*  By using this code you agree to indemnify Arnan de Gans from any
*  liability that might arise from it's use.
------------------------------------------------------------------------------------ */

/*-------------------------------------------------------------
 Name:      ajdg_grpwidgets
 Purpose:   Group adverts
 Since:		3.19
-------------------------------------------------------------*/
class ajdg_grpwidgets extends WP_Widget {

	/*-------------------------------------------------------------
	 Purpose:   Construct the widget
	-------------------------------------------------------------*/
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'ajdg_grpwidgets',
			'description' => 'Show a group of adverts in any widget area.',
		);
		parent::__construct( 'ajdg_grpwidgets', 'AdRotate Group', $widget_ops );
	}

	/*-------------------------------------------------------------
	 Purpose:   Display the widget
	-------------------------------------------------------------*/
	public function widget($args, $instance) {
		global $adrotate_config, $post, $blog_id;

		extract($args);
		if(empty($instance['title'])) $instance['title'] = '';
		if(empty($instance['groupid'])) $instance['groupid'] = 0;
		if(empty($instance['categories'])) $instance['categories'] = '';
		if(empty($instance['pages'])) $instance['pages'] = '';
		$instance['before'] = (empty($instance['before'])) ? '' : stripslashes(htmlspecialchars_decode($instance['before'], ENT_QUOTES)).'.';
		$instance['after'] = (empty($instance['after'])) ? '' : '.'.stripslashes(htmlspecialchars_decode($instance['after'], ENT_QUOTES));
		if(empty($instance['network'])) $instance['network'] = 0;

		// Determine post injection
		if($instance['categories'] != '' OR $instance['pages'] != '') {
			$show = false;
			
			$categories = explode(",", $instance['categories']);
			$pages = explode(",", $instance['pages']);

			if(is_page($pages) OR is_category($categories) OR in_category($categories)) {
				$show = true;
			}
		} else {
			$show = true;
		}
		
		if($show) {
			$title = apply_filters('widget_title', $instance['title']);

			echo $before_widget;
			if($title) {
				echo $before_title . $title . $after_title;
			}
			
			if($adrotate_config['widgetalign'] == 'Y') echo '<ul><li>';

			if($adrotate_config['w3caching'] == 'Y') {
				echo '<!-- mfunc '.W3TC_DYNAMIC_SECURITY.' -->';
				echo 'echo '.$instance['before'].'adrotate_group('.$instance['groupid'].', 0, 0, '.$instance['network'].')'.$instance['after'].';';
				echo '<!-- /mfunc '.W3TC_DYNAMIC_SECURITY.' -->';
			} else {
				echo $instance['before'].adrotate_group($instance['groupid'], 0, 0, $instance['network']).$instance['after'];
			}
					
			if($adrotate_config['widgetalign'] == 'Y') echo '</li></ul>';
			
			echo $after_widget;
		}
	}

	/*-------------------------------------------------------------
	 Purpose:   Save the widget options per instance
	-------------------------------------------------------------*/
	public function update($new_instance, $old_instance) {
		global $wpdb;

		$new_instance['title'] = strip_tags($new_instance['title']);
		list($groupid, $network) = explode("-", strip_tags($new_instance['groupid']));
		$new_instance['groupid'] = $groupid;
		$new_instance['network'] = ($network == 'n') ? 1 : 0;
		$new_instance['before'] = htmlspecialchars(trim($new_instance['before'], "\t\n "), ENT_QUOTES);
		$new_instance['after'] = htmlspecialchars(trim($new_instance['after'], "\t\n "), ENT_QUOTES);


		// Grab group settings from primary site
		$networked = get_site_option('adrotate_network_settings');
		if($new_instance['network'] == 1 AND adrotate_is_networked() AND $license['type'] == 'Developer') {
			$current_blog = $wpdb->blogid;
			switch_to_blog($networked['primary']);
		}

		$group = $wpdb->get_row("SELECT `cat`, `cat_loc`, `page`, `page_loc` FROM `{$wpdb->prefix}adrotate_groups` WHERE `id` = {$new_instance['groupid']};");
		if(adrotate_is_networked() AND $license['type'] == 'Developer') {
			switch_to_blog($current_blog);
		}
		$new_instance['categories'] = ($group->cat_loc == 5) ? $group->cat : ''; // Post injection
		$new_instance['pages'] = ($group->page_loc == 5) ? $group->page : ''; // Page injection

		$instance = wp_parse_args($new_instance, $old_instance);

		return $instance;
	}

	/*-------------------------------------------------------------
	 Purpose:   Display the widget options for admins
	-------------------------------------------------------------*/
	public function form($instance) {
		global $wpdb, $blog_id;

		$defaults = array();
		$instance = wp_parse_args( (array) $instance, $defaults );
		$license = (!adrotate_is_networked()) ? get_option('adrotate_activate') : get_site_option('adrotate_activate');
		
		$title = $groupid = $categories = $pages = $before = $after = $network = '';
		extract($instance);
		$title = esc_attr($title);
		$groupid = esc_attr($groupid);
		$categories = esc_attr($categories);
		$pages = esc_attr($pages);
		$before = esc_attr( $before );
		$after = esc_attr( $after );
		$network = esc_attr( $network );
		
		$groups = $groups_local = $groups_network = array();
		// Grab group settings from primary site
		$networked = get_site_option('adrotate_network_settings');
		if(adrotate_is_networked() AND $license['type'] == 'Developer') {
			// Get groups from site
			if($networked['site_dashboard'] == "Y") {
				$groups_local = $wpdb->get_results("SELECT `id`, `name` FROM `{$wpdb->prefix}adrotate_groups` WHERE `name` != '' ORDER BY `id` ASC;");
				$groups['0'] = '-- '.__('Choose a group', 'adrotate-pro').' --';
				foreach($groups_local as $local) {
					$groups[$local->id] = $local->name;
	 			}
			}
			
			// Get groups from network
			if($networked['primary'] != $blog_id) {
				$current_blog = $wpdb->blogid;
				switch_to_blog($networked['primary']);
				$groups_network = $wpdb->get_results("SELECT `id`, `name` FROM `{$wpdb->prefix}adrotate_groups` WHERE `name` != '' ORDER BY `id` ASC;");
				$groups['0-n'] = '-- '.__('Groups from network', 'adrotate-pro').' --';
				foreach($groups_network as $group) {
					$groups[$group->id.'-n'] = $group->name;
	 			}
				switch_to_blog($current_blog);
			}
		} else {
			$groups_local = $wpdb->get_results("SELECT `id`, `name` FROM `{$wpdb->prefix}adrotate_groups` WHERE `name` != '' ORDER BY `id` ASC;");
			foreach($groups_local as $local) {
				$groups[$local->id] = $local->name;
 			}
		}
?>
		<?php if($categories != '' OR $pages != '') { ?>
		<p><?php _e('NOTE: This widget has Post Injection enabled!', 'adrotate-pro'); ?></p>
		<?php } ?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title (optional):', 'adrotate-pro'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			<br />
			<small><?php _e('HTML will be stripped out.', 'adrotate-pro'); ?></small>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('groupid'); ?>"><?php _e('Group:', 'adrotate-pro'); ?></label><br />
			<select id="<?php echo $this->get_field_id('groupid'); ?>" name="<?php echo $this->get_field_name('groupid'); ?>">
			<?php if($groups) { ?>
				<?php $groupid = ($network == 1) ? $groupid.'-n' : $groupid;	?>
				<?php foreach($groups as $group => $title) { ?>
					<?php list($id, $is_network) = explode('-', $group); ?>
			        <option value="<?php echo $group;?>" <?php if($groupid == $id) { echo 'selected'; } ?>><?php echo $id;?> - <?php echo $title; ?></option>
	 			<?php } ?>
			<?php } ?>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('before'); ?>"><?php _e('Wrapper before:', 'adrotate-pro'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('before'); ?>" name="<?php echo $this->get_field_name('before'); ?>" type="text" value="<?php echo $before; ?>" />
			<br /><label for="<?php echo $this->get_field_id('after'); ?>"><?php _e('Wrapper after:', 'adrotate-pro'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('after'); ?>" name="<?php echo $this->get_field_name('after'); ?>" type="text" value="<?php echo $after; ?>" />
			<br /><small><?php _e('Simple HTML to center an advert or apply a paragraph for example.', 'adrotate-pro'); ?></small>
		</p>
<?php
	}
}
?>