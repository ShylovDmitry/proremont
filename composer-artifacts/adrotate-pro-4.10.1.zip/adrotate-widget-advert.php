<?php
/* ------------------------------------------------------------------------------------
*  COPYRIGHT AND TRADEMARK NOTICE
*  Copyright 2008-2017 Arnan de Gans. All Rights Reserved.
*  ADROTATE is a registered trademark of Arnan de Gans.

*  COPYRIGHT NOTICES AND ALL THE COMMENTS SHOULD REMAIN INTACT.
*  By using this code you agree to indemnify Arnan de Gans from any
*  liability that might arise from it's use.
------------------------------------------------------------------------------------ */

/*-------------------------------------------------------------
 Name:      ajdg_grp_widgets
 Purpose:   Group adverts
 Since:		3.19
-------------------------------------------------------------*/
class ajdg_bnnrwidgets extends WP_Widget {

	/*-------------------------------------------------------------
	 Purpose:   Construct the widget
	-------------------------------------------------------------*/
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'ajdg_bnnrwidgets',
			'description' => 'Show a single advert in any widget area.',
		);
		parent::__construct( 'ajdg_bnnrwidgets', 'AdRotate Advert', $widget_ops );
	}

	/*-------------------------------------------------------------
	 Purpose:   Display the widget
	-------------------------------------------------------------*/
	public function widget($args, $instance) {
		global $adrotate_config, $blog_id;

		extract($args);
		if(empty($instance['title'])) $instance['title'] = '';
		if(empty($instance['adid'])) $instance['adid'] = 0;
		$instance['before'] = (empty($instance['before'])) ? '' : stripslashes(htmlspecialchars_decode($instance['before'], ENT_QUOTES)).'.';
		$instance['after'] = (empty($instance['after'])) ? '' : '.'.stripslashes(htmlspecialchars_decode($instance['after'], ENT_QUOTES));
		if(empty($instance['network'])) $instance['network'] = 0;

        $title = apply_filters('widget_title', $instance['title']);

		echo $before_widget;
		if($title) {
			echo $before_title . $title . $after_title;
		}
		
		if($adrotate_config['widgetalign'] == 'Y') echo '<ul><li>';

		if($adrotate_config['w3caching'] == 'Y') {
			echo '<!-- mfunc '.W3TC_DYNAMIC_SECURITY.' -->';
			echo 'echo '.$instance['before'].'adrotate_ad('.$instance['adid'].', true, 0, '.$instance['network'].')'.$instance['after'].';';
			echo '<!-- /mfunc '.W3TC_DYNAMIC_SECURITY.' -->';
		} else {
			echo $instance['before'].adrotate_ad($instance['adid'], true, 0, $instance['network']).$instance['after'];
		}
		
		if($adrotate_config['widgetalign'] == 'Y') echo '</li></ul>';
		
		echo $after_widget;

	}

	/*-------------------------------------------------------------
	 Purpose:   Save the widget options per instance
	-------------------------------------------------------------*/
	public function update($new_instance, $old_instance) {
		global $wpdb;

		$new_instance['title'] = strip_tags($new_instance['title']);
		list($adid, $network) = explode("-", strip_tags($new_instance['adid']));
		$new_instance['adid'] = $adid;
		$new_instance['network'] = ($network == 'n') ? 1 : 0;
		$new_instance['before'] = htmlspecialchars(trim($new_instance['before'], "\t\n "), ENT_QUOTES);
		$new_instance['after'] = htmlspecialchars(trim($new_instance['after'], "\t\n "), ENT_QUOTES);

		$instance = wp_parse_args($new_instance, $old_instance);

		return $instance;
	}

	/*-------------------------------------------------------------
	 Purpose:   Display the widget options for admins
	-------------------------------------------------------------*/
	public function form($instance) {
		global $wpdb, $blog_id;

		$defaults = array();
		$instance = wp_parse_args( (array) $instance, $defaults );
		$license = (!adrotate_is_networked()) ? get_option('adrotate_activate') : get_site_option('adrotate_activate');
		
		$title = $adid = $before = $after = $network = '';
		extract($instance);
		$title = esc_attr( $title );
		$adid = esc_attr( $adid );
		$before = esc_attr( $before );
		$after = esc_attr( $after );
		$network = esc_attr( $network );

		$adverts = $adverts_local = $adverts_network = array();
		// Grab adverts from primary site
		$networked = get_site_option('adrotate_network_settings');
		if(adrotate_is_networked() AND $license['type'] == 'Developer') {
			// Get groups from site
			if($networked['site_dashboard'] == "Y") {
				$adverts_local = $wpdb->get_results("SELECT `id`, `title` FROM `{$wpdb->prefix}adrotate` WHERE (`type` = 'active' OR `type` = '2days' OR `type` = '7days') ORDER BY `id` ASC;");
				$adverts['0'] = '-- '.__('Choose an advert', 'adrotate-pro').' --';
				foreach($adverts_local as $local) {
					$adverts[$local->id] = $local->title;
	 			}
			}
			
			// Get groups from network
			if($networked['primary'] != $blog_id) {
				$current_blog = $wpdb->blogid;
				switch_to_blog($networked['primary']);
				$adverts_network = $wpdb->get_results("SELECT `id`, `title` FROM `{$wpdb->prefix}adrotate` WHERE (`type` = 'active' OR `type` = '2days' OR `type` = '7days') ORDER BY `id` ASC;");
				$adverts['0-n'] = '-- '.__('Adverts from network', 'adrotate-pro').' --';
				foreach($adverts_network as $advert) {
					$adverts[$advert->id.'-n'] = $advert->title;
	 			}
				switch_to_blog($current_blog);
			}
		} else {
			$adverts_local = $wpdb->get_results("SELECT `id`, `title` FROM `{$wpdb->prefix}adrotate` WHERE (`type` = 'active' OR `type` = '2days' OR `type` = '7days') ORDER BY `id` ASC;");
			foreach($adverts_local as $local) {
				$adverts[$local->id] = $local->title;
			}
		}
		unset($adverts_local, $adverts_network);
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title (optional):', 'adrotate-pro'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
			<br />
			<small><?php _e('HTML will be stripped out.', 'adrotate-pro'); ?></small>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('adid'); ?>"><?php _e('Advert:', 'adrotate-pro'); ?></label><br />
			<select id="<?php echo $this->get_field_id('adid'); ?>" name="<?php echo $this->get_field_name('adid'); ?>">
			<?php if($adverts) { ?>
				<?php $adid = ($network == 1) ? $adid.'-n' : $adid;	?>
				<?php foreach($adverts as $ad => $title) { ?>
					<?php list($id, $is_network) = explode('-', $ad); ?>
			        <option value="<?php echo $ad;?>" <?php if($adid == $id) { echo 'selected'; } ?>><?php echo $id;?> - <?php echo $title;?></option>
	 			<?php } ?>
			<?php } ?>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('before'); ?>"><?php _e('Wrapper before:', 'adrotate-pro'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('before'); ?>" name="<?php echo $this->get_field_name('before'); ?>" type="text" value="<?php echo $before; ?>" />
			<br /><label for="<?php echo $this->get_field_id('after'); ?>"><?php _e('Wrapper after:', 'adrotate-pro'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('after'); ?>" name="<?php echo $this->get_field_name('after'); ?>" type="text" value="<?php echo $after; ?>" />
			<br /><small><?php _e('Simple HTML to center an advert or apply a paragraph for example.', 'adrotate-pro'); ?></small>
		</p>
<?php
	}

}
?>