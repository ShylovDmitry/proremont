=== AdRotate Professional ===
Contributors: Arnan de Gans
Requires at least: 3.8
Tested up to: 4.8
Stable tag: 4.10.1

== Description ==

Get the most intuitive ad manager and start making money with your website.

== COPYRIGHT AND TRADEMARK NOTICE ==

Copyright 2008-2017 Arnan de Gans. All Rights Reserved.
ADROTATE is a registered trademark of Arnan de Gans.

AdRotate Pro may be used as long as you own and register a valid license key.
COPYRIGHT NOTICES AND ALL THE COMMENTS SHOULD REMAIN INTACT.
By using this code you agree to indemnify Arnan de Gans from any liability that might arise from it's use.

(Re-)Selling the code for this program, in part or full, without prior written consent is expressly forbidden.

Using this code, in part or full, to create derivate work, new scripts or products is expressly forbidden.
Obtain permission before redistributing this software over the Internet or in any other medium. 
In all cases copyright and header must remain intact.
This Copyright is in full effect in any country that has International Trade Agreements with the United States of America or with the European Union.

Removing any of the copyright notices is expressly forbidden. 
For more information on how to obtain a license please visit the [AdRotate website](https://ajdg.solutions/products/adrotate-for-wordpress/)