<?php
/* ------------------------------------------------------------------------------------
*  COPYRIGHT AND TRADEMARK NOTICE
*  Copyright 2008-2017 Arnan de Gans. All Rights Reserved.
*  ADROTATE is a registered trademark of Arnan de Gans.

*  COPYRIGHT NOTICES AND ALL THE COMMENTS SHOULD REMAIN INTACT.
*  By using this code you agree to indemnify Arnan de Gans from any
*  liability that might arise from it's use.
------------------------------------------------------------------------------------ */

if(!$transaction_id) { 
	$edit_id = $wpdb->get_var("SELECT `id` FROM `{$wpdb->prefix}adrotate_transactions` WHERE `reference` = '' ORDER BY `id` DESC LIMIT 1;");
	if($edit_id == 0) {
	    $wpdb->insert($wpdb->prefix."adrotate_transactions", array('ad' => 0, 'user' => 0, 'reference' => '', 'note' => '', 'billed' => $now, 'paid' => 0, 'amount' => 0));
	    $edit_id = $wpdb->insert_id;
	}
	$transaction_id = $edit_id;
}

$edit_transaction = $wpdb->get_row("SELECT * FROM `{$wpdb->prefix}adrotate_transactions` WHERE `id` = {$transaction_id};");

$adverts = $wpdb->get_results("SELECT `{$wpdb->prefix}adrotate`.`id`, `title`, `display_name` FROM `{$wpdb->prefix}adrotate`, `{$wpdb->prefix}adrotate_linkmeta`, `{$wpdb->users}` WHERE `{$wpdb->prefix}adrotate`.`id` = `{$wpdb->prefix}adrotate_linkmeta`.`ad` AND `{$wpdb->prefix}adrotate_linkmeta`.`user` = `{$wpdb->users}`.`id` AND `group` = 0 AND `schedule` = 0 AND `type` != 'empty' AND `type` != 'a_empty' AND `type` != 'archived' AND `type` != 'bin' ORDER BY `{$wpdb->prefix}adrotate`.`id` ASC;");
?>
	<form method="post" action="admin.php?page=adrotate-transactions&view=edit">
	<?php wp_nonce_field('adrotate_save_transaction','adrotate_nonce'); ?>
	<input type="hidden" name="adrotate_transaction" value="<?php echo $edit_transaction->id;?>" />
	<input type="hidden" name="adrotate_paid" value="<?php echo $edit_transaction->paid;?>" />

<?php if($edit_transaction->ad == '') { ?>
	<h2><?php _e('New Transaction', 'adrotate-pro'); ?></h2>
<?php } else { ?> 
	<h2><?php _e('Edit Transaction', 'adrotate-pro'); ?></h2>
<?php } ?>
	<p><em><?php _e('Creating a transaction will disable the selected advert until the transaction is marked paid.', 'adrotate-pro'); ?></em></p>
	<table class="widefat" style="margin-top: .5em">

		<tbody>
		<tr>
	        <th width="15%"><?php _e('Advert', 'adrotate-pro'); ?></th>
	        <td>
	        	<label for="adrotate_advert"><select id="adrotate_advert" name="adrotate_advert" tabindex="1">
				<?php if(count($adverts) > 0) { ?>
					<?php foreach($adverts as &$ad) { ?>
				        <option value="<?php echo $ad->id;?>" <?php if($edit_transaction->ad == $ad->id) { echo 'selected'; } ?>><?php echo $ad->title;?> (<?php echo $ad->display_name;?>)</option>
		 			<?php } ?>
				<?php } else { ?>
			        <option value="0"><?php _e('There are no unpaid adverts!', 'adrotate-pro'); ?></option>
				<?php } ?>
				</select> <em><?php _e('Choose an advert!', 'adrotate-pro'); ?></em></label>
	        </td>
    	</tr>
		<tr>
	        <th width="15%"><?php _e('Reference', 'adrotate-pro'); ?></th>
	        <td>
	        	<label for="adrotate_reference"><input tabindex="2" id="adrotate_reference" name="adrotate_reference" type="text" size="50" class="search-input" value="<?php echo stripslashes($edit_transaction->reference);?>" autocomplete="off" /> <em><?php _e('Use this for a Paypal Transaction ID or similar.', 'adrotate-pro'); ?> <?php _e('Visible to Advertisers!', 'adrotate-pro'); ?></em></label>
	        </td>
    	</tr>
		<tr>
	        <th width="15%"><?php _e('Note / Remark', 'adrotate-pro'); ?></th>
	        <td>
	        	<label for="adrotate_note"><input tabindex="3" id="adrotate_note" name="adrotate_note" type="text" size="50" class="search-input" value="<?php echo stripslashes($edit_transaction->note);?>" autocomplete="off" /> <em><?php _e('Personal note.', 'adrotate-pro'); ?></em></label>
	        </td>
    	</tr>
		<tr>
	        <th width="15%"><?php _e('Amount due', 'adrotate-pro'); ?></th>
	        <td>
	        	<label for="adrotate_amount"><?php echo $adrotate_config['payment_currency']; ?> <input tabindex="4" id="adrotate_amount" name="adrotate_amount" type="text" size="10" class="search-input" value="<?php echo stripslashes($edit_transaction->amount);?>" autocomplete="off" /></label>
	        </td>
    	</tr>
	    <tr>
	        <th width="15%"><?php _e('Advert budget', 'adrotate-pro'); ?></th>
			<td><label for="adrotate_budget"><input tabindex="15" type="checkbox" name="adrotate_budget" value="1" <?php if($edit_transaction->budget == '1') { ?>checked="checked"<?php } ?> /> <?php _e('Credit the billed amount to the adverts budget automatically when the transaction completes.', 'adrotate-pro'); ?></label></td>
		</tr>
		</tbody>

	</table>

	<p><em><strong><?php _e('Note:', 'adrotate-pro'); ?></strong> <?php _e('Crediting the payment to the advert will cause the advert to expire when the budget reaches 0. If you do not use this option the advert will expire normally using schedules.', 'adrotate-pro'); ?></em></p>

	<p class="submit">
		<input tabindex="6" type="submit" name="adrotate_transaction_submit" class="button-primary" value="<?php _e('Save Transaction', 'adrotate-pro'); ?>" />
		<a href="admin.php?page=adrotate-transactions" class="button"><?php _e('Cancel', 'adrotate-pro'); ?></a>
	</p>
	</form>