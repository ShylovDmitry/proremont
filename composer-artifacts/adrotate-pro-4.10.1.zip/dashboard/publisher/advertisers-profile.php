<?php
/* ------------------------------------------------------------------------------------
*  COPYRIGHT AND TRADEMARK NOTICE
*  Copyright 2008-2017 Arnan de Gans. All Rights Reserved.
*  ADROTATE is a registered trademark of Arnan de Gans.

*  COPYRIGHT NOTICES AND ALL THE COMMENTS SHOULD REMAIN INTACT.
*  By using this code you agree to indemnify Arnan de Gans from any
*  liability that might arise from it's use.
------------------------------------------------------------------------------------ */
$permissions = get_user_meta($user_id, 'adrotate_permissions', 1);
$notes = get_user_meta($user_id, 'adrotate_notes', 1);
if($adrotate_config['payment_enable'] == "Y") {
	$transactions = $wpdb->get_results("SELECT * FROM `{$wpdb->prefix}adrotate_transactions` WHERE `user` = {$user_id} AND `reference` != '' ORDER BY `billed` ASC;");
} else {
	$transactions = array();
}

if(!isset($permissions['edit'])) $permissions['edit'] = 'N';
if(!isset($permissions['mobile'])) $permissions['mobile'] = 'N';
if(!isset($permissions['geo'])) $permissions['geo'] = 'N';
?>

<h2><?php _e('Advertiser Profile', 'adrotate-pro'); ?></h2>
<div id="dashboard-widgets-wrap">
	<div id="dashboard-widgets" class="metabox-holder">

		<div id="postbox-container-1" class="postbox-container" style="width:50%;">
			<div id="normal-sortables" class="meta-box-sortables ui-sortable">
				
				<h3><?php _e('Profile', 'adrotate-pro'); ?></h3>
				<form name="request" id="post" method="post" action="admin.php?page=adrotate-advertisers&view=profile">
				<?php wp_nonce_field('adrotate_save_advertiser','adrotate_nonce'); ?>
				<input type="hidden" name="adrotate_user" value="<?php echo $user_id;?>" />
				<div class="postbox-adrotate">
					<div class="inside">
						<table width="100%">
							<thead>
							<tr class="first">
								<td width="50%"><strong><?php _e('Who', 'adrotate-pro'); ?></strong></td>
								<td width="50%"><strong><?php _e('Specs', 'adrotate-pro'); ?></strong></td>
							</tr>
							</thead>
							
							<tbody>
							<tr class="first">
								<td class="first b"><?php echo $advertisers[$user_id]['name']; ?><br /><a class="row-title" href="<?php echo admin_url('/admin.php?page=adrotate-advertisers&view=contact&user='.$user_id);?>" title="<?php _e('Contact', 'adrotate-pro'); ?>"><?php echo $advertisers[$user_id]['email']; ?></a></td>
								<td class="b"><?php echo $advertisers[$user_id]['has_adverts']; ?> Adverts<br /><?php echo $advertisers[$user_id]['has_unpaid']; ?> Unpaid</td>
							</tr>
							</tbody>

							<thead>
							<tr>
								<td colspan="2"><strong><?php _e('Notes', 'adrotate-pro'); ?></strong></td>
							</tr>
							</thead>
							
							<tbody>
							<tr>
								<td colspan="2">
									<textarea tabindex="1" name="adrotate_notes" cols="50" rows="5"><?php echo esc_attr($notes); ?></textarea><br />
									<em><?php _e('No HTML/Javascript or code allowed.', 'adrotate-pro'); ?></em>

								</td>
							</tr>
							</tbody>

							<thead>
							<tr>
								<td colspan="2"><strong><?php _e('Permissions', 'adrotate-pro'); ?></strong></td>
							</tr>
							</thead>
							
							<tbody>
							<tr>
								<td colspan="2">
						        	<label for="adrotate_can_edit"><input tabindex="2" type="checkbox" name="adrotate_can_edit" <?php if($permissions['edit'] == 'Y') { ?>checked="checked" <?php } ?> /> <?php _e('Create and edit their own adverts?', 'adrotate-pro'); ?></label><br />
						        	<label for="adrotate_can_mobile"><input tabindex="3" type="checkbox" name="adrotate_can_mobile" <?php if($permissions['mobile'] == 'Y') { ?>checked="checked" <?php } ?> /> <?php _e('Specify devices for mobile adverts?', 'adrotate-pro'); ?></label><br />
						        	<label for="adrotate_can_geo"><input tabindex="4" type="checkbox" name="adrotate_can_geo" <?php if($permissions['geo'] == 'Y') { ?>checked="checked" <?php } ?> /> <?php _e('Can set up Geo Targeting?', 'adrotate-pro'); ?></label><br />

								</td>
							</tr>
							</tbody>
						</table>
					</div>
				</div>

				<p class="submit">
					<input tabindex="4" type="submit" name="adrotate_advertiser_submit" class="button-primary" value="<?php _e('Save', 'adrotate-pro'); ?>" />
					<a href="admin.php?page=adrotate-advertisers" class="button"><?php _e('Back', 'adrotate-pro'); ?></a>
				</p>
				</form>		

			</div>
		</div>

		<div id="postbox-container-3" class="postbox-container" style="width:50%;">
			<div id="side-sortables" class="meta-box-sortables ui-sortable">
						
				<h3><?php _e('Last 10 Transactions', 'adrotate-pro'); ?></h3>
				<div class="postbox-adrotate">
					<div class="inside">
						<table width="100%">
							<thead>
							<tr class="first">
								<td width="28%"><strong><?php _e('Date', 'adrotate-pro'); ?></strong></td>
								<td><strong><?php _e('Reference / Advert', 'adrotate-pro'); ?></strong></td>
								<td width="20%"><strong><?php _e('Amount', 'adrotate-pro'); ?></strong></td>
								<td width="7%"><center><strong><?php _e('Paid', 'adrotate-pro'); ?></strong></center></td>
							</tr>
							</thead>
							<tbody>
							<?php if(count($transactions) > 0) { ?>
								<?php foreach($transactions as $t) {
									$advert_name = $wpdb->get_var("SELECT `title` FROM `{$wpdb->prefix}adrotate` WHERE `id` = {$t->ad};");
									$tick = '<img src="'.plugins_url('../../images/tick.png', __FILE__).'" width="10" height"10" title="'.date_i18n("F d, Y", $t->paid).'" />';
									$cross = '<img src="'.plugins_url('../../images/cross.png', __FILE__).'" width="10" height"10" title="'.__('Unpaid', 'adrotate-pro').'" />';
								?>
							<tr class="first">
								<td class="first b" valign="top"><?php echo date_i18n("F d, Y", $t->billed); ?></td>
								<td class="b"><a class="row" href="<?php echo admin_url('/admin.php?page=adrotate-transactions&view=edit&transaction='.$t->id);?>" title="<?php echo $t->id; ?>"><?php echo $t->reference; ?></a><br /><?php echo $advert_name; ?></td>
								<td class="b" valign="top"><?php echo $adrotate_config['payment_currency'].' '.number_format($t->amount, 2, '.', ''); ?></td>
								<td class="b" valign="top"><center><?php echo ($t->paid > 0) ? $tick : $cross ; ?></center></td>
							</tr>
								<?php } ?>
							<?php } else { ?>
							<tr class="first">
								<td class="first b" colspan="4"><?php _e('Nothing here!', 'adrotate-pro'); ?></td>
							</tr>
							<?php } ?>
							</tbody>
						</table>
					</div>
				</div>

			</div>	
		</div>

	</div>
</div>