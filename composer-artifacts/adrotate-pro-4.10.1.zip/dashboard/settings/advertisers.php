<?php
/* ------------------------------------------------------------------------------------
*  COPYRIGHT AND TRADEMARK NOTICE
*  Copyright 2008-2017 Arnan de Gans. All Rights Reserved.
*  ADROTATE is a registered trademark of Arnan de Gans.

*  COPYRIGHT NOTICES AND ALL THE COMMENTS SHOULD REMAIN INTACT.
*  By using this code you agree to indemnify Arnan de Gans from any
*  liability that might arise from it's use.
------------------------------------------------------------------------------------ */
?>

<form name="settings" id="post" method="post" action="admin.php?page=adrotate-settings&tab=advertisers">
<?php wp_nonce_field('adrotate_settings','adrotate_nonce_settings'); ?>
<input type="hidden" name="adrotate_settings_tab" value="<?php echo $active_tab; ?>" />

<h2><?php _e('Advertisers', 'adrotate-pro'); ?></h2>
<span class="description"><?php _e('Enable advertisers so they can review and manage their own adverts.', 'adrotate-pro'); ?></span>
<table class="form-table">
	<tr>
		<th valign="top"><?php _e('Enable Advertisers', 'adrotate-pro'); ?></th>
		<td>
			<label for="adrotate_enable_advertisers"><input type="checkbox" name="adrotate_enable_advertisers" <?php if($adrotate_config['enable_advertisers'] == 'Y') { ?>checked="checked" <?php } ?> /> <?php _e('Allow adverts to be coupled to users (Advertisers).', 'adrotate-pro'); ?></label>
		</td>
	</tr>
	<tr>
		<th valign="top"><?php _e('Edit/update adverts', 'adrotate-pro'); ?></th>
		<td>
			<label for="adrotate_enable_editing"><input type="checkbox" name="adrotate_enable_editing" <?php if($adrotate_config['enable_editing'] == 'Y') { ?>checked="checked" <?php } ?> /> <?php _e('Allow advertisers to add new or edit their adverts.', 'adrotate-pro'); ?></label>
		</td>
	</tr>
	<tr>
		<th valign="top"><?php _e('Mobile adverts', 'adrotate-pro'); ?></th>
		<td>
			<input type="checkbox" name="adrotate_enable_mobile_advertisers" <?php if($adrotate_config['enable_mobile_advertisers'] == 1) { ?>checked="checked" <?php } ?> /> <?php _e('Allow advertisers to specify on which devices their ads will show.', 'adrotate-pro'); ?>
		</td>
	</tr>
	<tr>
		<th valign="top"><?php _e('Geo Targeting', 'adrotate-pro'); ?></th>
		<td>
			<input type="checkbox" name="adrotate_enable_geo_advertisers" <?php if($adrotate_config['enable_geo_advertisers'] == 1) { ?>checked="checked" <?php } ?> /> <?php _e('Allow advertisers to specify where their ads will show. Geo Targeting has to be enabled, too.', 'adrotate-pro'); ?>
		</td>
	</tr>
	<tr>
		<th valign="top"><?php _e('Advertiser role', 'adrotate-pro'); ?></th>
		<td>
			<label for="adrotate_role"><input type="checkbox" name="adrotate_role" <?php if(is_object(get_role('adrotate_advertiser'))) { ?>checked="checked" <?php } ?> /> <?php _e('Create a seperate user role for your advertisers.', 'adrotate-pro'); ?></label><br />
			<span class="description"><?php _e('Don\'t forget to give these users access to their advertiser dashboard via the Roles tab.', 'adrotate-pro'); ?></span>
		</td>
	</tr>
</table>

<h3><?php _e('Transactions', 'adrotate-pro'); ?></h3>
<table class="form-table">
	<tr>
		<th valign="top"><?php _e('Transactions', 'adrotate-pro'); ?></th>
		<td>
			<label for="adrotate_transactions"><input type="checkbox" name="adrotate_transactions" <?php if($adrotate_config['payment_enable'] == "Y") { ?>checked="checked" <?php } ?> /> <?php _e('Enable the transactions.', 'adrotate-pro'); ?></label><br /><em><?php _e('Disabling transactions will update all adverts. This can not be undone!', 'adrotate-pro'); ?></em>
		</td>
	</tr>
	<tr>
		<th valign="top"><?php _e('Currency', 'adrotate-pro'); ?></th>
		<td>
			<label for="adrotate_payment_currency"><select name="adrotate_payment_currency">
				<option value="USD" <?php if($adrotate_config['payment_currency'] == 'USD') { echo 'selected'; } ?>><?php _e('USD - United States Dollar', 'adrotate-pro'); ?></option>
				<option value="EUR" <?php if($adrotate_config['payment_currency'] == 'EUR') { echo 'selected'; } ?>><?php _e('EUR - Euro', 'adrotate-pro'); ?></option>
				<option value="CAD" <?php if($adrotate_config['payment_currency'] == 'CAD') { echo 'selected'; } ?>><?php _e('CAD - Canadian Dollars', 'adrotate-pro'); ?></option>
				<option value="AUD" <?php if($adrotate_config['payment_currency'] == 'AUD') { echo 'selected'; } ?>><?php _e('AUD - Australian Dollars', 'adrotate-pro'); ?></option>
				<option value="GBP" <?php if($adrotate_config['payment_currency'] == 'GBP') { echo 'selected'; } ?>><?php _e('GBP - Pounds Sterling', 'adrotate-pro'); ?></option>
				<option value="BRL" <?php if($adrotate_config['payment_currency'] == 'BRL') { echo 'selected'; } ?>><?php _e('BRL - Brazilian Real', 'adrotate-pro'); ?></option>
				<option value="JPY" <?php if($adrotate_config['payment_currency'] == 'JPY') { echo 'selected'; } ?>><?php _e('JPY - Japanese Yen', 'adrotate-pro'); ?></option>
				<option value="ZAR" <?php if($adrotate_config['payment_currency'] == 'ZAR') { echo 'selected'; } ?>><?php _e('ZAR - South African rand', 'adrotate-pro'); ?></option>
				<option value="RUB" <?php if($adrotate_config['payment_currency'] == 'RUB') { echo 'selected'; } ?>><?php _e('RUB - Russian ruble', 'adrotate-pro'); ?></option>
			</select> <?php _e('Choose your currency.', 'adrotate-pro'); ?><br /><em><?php _e('Default is USD.', 'adrotate-pro'); ?></em></label>
		</td>
	</tr>
	<tr>
		<th valign="top"><?php _e('Payment overdue', 'adrotate-pro'); ?></th>
		<td>
			<label for="adrotate_payment_overdue"><?php _e('After', 'adrotate-pro'); ?> <select name="adrotate_payment_overdue">
				<option value="0" <?php if($adrotate_config['payment_overdue'] == 0) { echo 'selected'; } ?>><?php _e('Never', 'adrotate-pro'); ?></option>
				<option value="2" <?php if($adrotate_config['payment_overdue'] == 2) { echo 'selected'; } ?>><?php _e('2 days', 'adrotate-pro'); ?></option>
				<option value="5" <?php if($adrotate_config['payment_overdue'] == 5) { echo 'selected'; } ?>><?php _e('5 days', 'adrotate-pro'); ?></option>
				<option value="7" <?php if($adrotate_config['payment_overdue'] == 7) { echo 'selected'; } ?>><?php _e('7 days', 'adrotate-pro'); ?></option>
				<option value="14" <?php if($adrotate_config['payment_overdue'] == 14) { echo 'selected'; } ?>><?php _e('14 days', 'adrotate-pro'); ?></option>
				<option value="21" <?php if($adrotate_config['payment_overdue'] == 21) { echo 'selected'; } ?>><?php _e('21 days', 'adrotate-pro'); ?></option>
			</select></label>
		</td>
	</tr>
	<tr>
		<th valign="top"><?php _e('Paypal Address', 'adrotate-pro'); ?></th>
		<td>
			<label for="adrotate_payment_address"><input name="adrotate_payment_address" type="text" class="search-input" size="25" value="<?php echo $adrotate_config['payment_address']; ?>" autocomplete="off" /> <?php _e('Your Paypal address.', 'adrotate-pro'); ?></label>
		</td>
	</tr>
</table>

<p class="submit">
  	<input type="submit" name="adrotate_save_options" class="button-primary" value="<?php _e('Update Options', 'adrotate-pro'); ?>" />
</p>
</form>