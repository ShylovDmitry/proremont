<?php
/**
* Simple Comment Editing class.
*
* Provides compatibility with Simple Comment Editing for editing and deleting comments with ratings.
* 
* @package 	Comment_Rating_Field_Pro
* @author 	Tim Carr
* @version 	3.3.7
*/
class Comment_Rating_Field_Pro_Simple_Comment_Editing {

	/**
     * Holds the class object.
     *
     * @since 	3.3.7
     *
     * @var 	object
     */
    public static $instance;

    /**
	 * Constructor
	 *
     * @since 	3.3.7
     */
	public function __construct() {

		add_filter( 'sce_extra_fields', array( $this, 'display_rating_fields' ), 10, 3 ); // Add rating fields
		add_filter( 'get_comment_text', array( $this, 'display_comment_rating' ), 10, 2 ); // Output rating on AJAX save
		
	}

	/**
	 * Called by Simple Comment Editing to append rating fields to the comment textarea when
	 * a user chooses to edit their comment.
	 *
	 * We use this instead of directly calling display_rating_fields(), as display_rating_fields()
	 * won't have $this->group populated.
	 *
	 * Called by:
	 * - add_filter( 'sce_extra_fields' )
	 *
	 * @since 	3.3.7
	 *
	 * @param 	string 	$comment_field_html 	Comment Field HTML
	 * @param 	int 	$post_id 				Post ID the comment being edited belongs to
	 * @param 	int 	$comment_id 			Comment ID of the comment being edited
	 * @return 	string 							Comment Field HTML
	 */
	public function display_rating_fields( $comment_field_html, $post_id, $comment_id ) {

		// Find group
		$group = Comment_Rating_Field_Pro_Groups::get_instance()->get_group_by_post_id( $post_id );
		if ( ! $group ) {
			return $comment_field_html;
		}
		
		// Get markup and apply filters to it
    	$html = Comment_Rating_Field_Pro_Rating_Output::get_instance()->build_comment_form_html( $group, $comment_id );
        $html = apply_filters( 'crfp_display_rating_field', $html, $group );

		// Depending on the rating input position, prepend or append the rating fields to the comment textarea
		switch ( $group['ratingInput']['position'] ) {
    		/**
    		 * Before All Fields
    		 */
    		case 'above':
    			return $html . $comment_field_html;
    			break;
    		
    		/**
    		 * Before Comment Field
    		 */
    		case 'middle':
    			return $html . $comment_field_html;
    			break;
    		

    		/**
    		 * After Comment Field
    		 */
    		default:
    			return $comment_field_html . $html;
    			break;
    	}

	}

	/**
	 * Used for Simple Comment Editing instead of comment_text, as we can get the Comment ID
	 * and Post ID, and then pass on the request to includes/global/rating-output.php::display_comment_rating()
	 *
	 * @since 	3.3.7
	 *
	 * @param 	string 		$comment_text 	Comment Text
	 * @param 	WP_Comment 	$comment 		Comment
	 * @return 	string 						Comment Text
	 */
	public function display_comment_rating( $comment_text, $comment ) {

		// Only run this if we're performing an Simple Comment Editing call
		if ( ! defined( 'DOING_SCE' ) ) {
			return $comment_text;
		}

		// Get Comment ID and Post ID
		$comment_id = $comment->comment_ID;
		$post_id 	= $comment->comment_post_ID;

		// Return comment text with rating
		return Comment_Rating_Field_Pro_Rating_Output::get_instance()->display_comment_rating( $comment_text, $post_id, $comment_id );

	}

	/**
     * Returns the singleton instance of the class.
     *
     * @since 	3.3.7
     *
     * @return 	object 	Class
     */
    public static function get_instance() {

        if ( ! isset( self::$instance ) && ! ( self::$instance instanceof self ) ) {
            self::$instance = new self;
        }

        return self::$instance;

    }

}