<?php
// Opening Tag
if ( $args['style'] == 'ol' || $args['style'] == 'ul' ) {
	?>
	<li class="crfp-comment-list-sorting">
	<?php
} else {
	?>
	<div class="crfp-comment-list-sorting">
	<?php
}
?>

	<form action="<?php echo get_permalink( $post->ID ); ?>" method="post">
		<div>
			<label for="crfp_sort"><?php _e( 'Sort By', 'comment-rating-field-pro-plugin' ); ?></label>
			<select name="crfp_sort" size="1" id="crfp_sort">
				<option value=""><?php _e( 'Default', 'comment-rating-field-pro-plugin' ); ?></option>
				<option value="rating_DESC"><?php _e( 'Rating: Highest to Lowest', 'comment-rating-field-pro-plugin' ); ?></option>
				<option value="rating_ASC"><?php _e( 'Rating: Lowest to Highest', 'comment-rating-field-pro-plugin' ); ?></option>

				<?php
				// If the group has the 'Was this Helpful' option enabled, provide sorting options
				if ( $this->group['ratingInput']['helpfulRating'] ) {
					?>
					<option value="helpful_DESC"><?php _e( 'Most Helpful Reviews', 'comment-rating-field-pro-plugin' ); ?></option>
					<option value="helpful_ASC"><?php _e( 'Least Helpful Reviews', 'comment-rating-field-pro-plugin' ); ?></option>
					<?php
				}
				?>
			</select>
			<input type="submit" name="submit" value="<?php _e( 'Sort', 'comment-rating-field-pro-plugin' ); ?>" />
		</div>
	</form>

<?php
// Closing Tag
if ( $args['style'] == 'ol' || $args['style'] == 'ul' ) {
	?>
	</li>
	<?php
} else {
	?>
	</div>
	<?php
}
?>